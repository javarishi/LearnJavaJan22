package com.h2kinfosys.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;


public class ConnectionUtil {
	
	// jdbc:mysql://host1:33060/sakila
	private String url = "jdbc:mysql://localhost:3306/sakila";
	private String user = "root";
	private String password = "password";
	
	public Connection getConnection() throws Exception{
			// Step1 - Driver
			//Driver driver = new Driver();
			//DriverManager.registerDriver(driver);
			// Step 2 - DriverManager
			Class.forName("com.mysql.cj.jdbc.Driver"); // reflection 
			// Step 3 - Connection
			Properties props = new Properties();
			props.setProperty("user", user);
			props.setProperty("password", password);
			Connection conn = DriverManager.getConnection(url, props);
			System.out.println(conn);
			return conn;
	}

	
	public void closeConnection(Connection conn) throws SQLException{
		if(conn != null) conn.close();
	}
}
