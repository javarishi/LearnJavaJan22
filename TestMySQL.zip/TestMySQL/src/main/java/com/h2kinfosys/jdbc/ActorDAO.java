package com.h2kinfosys.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class ActorDAO {
	
	private ConnectionUtil util = null;
	private String getAllActorsQuery = "Select * from Actor";
	private String getActorforActorID = "select * from actor where actor_id = ?";
	private String createActorQuery = "INSERT INTO ACTOR (first_name,last_name,last_update) VALUES ( ?, ? ,CURRENT_TIMESTAMP);";
	private String updateActorQuery = "UPDATE actor SET first_name = ?, last_name = ? ,last_update = CURRENT_TIMESTAMP WHERE actor_id = ?";
	private String deleteActorQuery = "DELETE FROM ACTOR WHERE actor_id = ?";
	
	public ActorDAO() {
		util = new ConnectionUtil();
	}
	
	
	
	public int createActors(List<ActorTO> actors) throws SQLException {
		Connection conn = null;
		int numberOfaffectedRows = 0;
		try {
			conn = util.getConnection();
			conn.setAutoCommit(false);
			PreparedStatement pStat = conn.prepareStatement(createActorQuery);
			
			for(ActorTO actor : actors) {
				pStat.setString(1, actor.getFirstName());
				pStat.setString(2, actor.getLastName());
				pStat.addBatch();
			}
			int[] results = pStat.executeBatch();
			numberOfaffectedRows = results.length;
			conn.commit();
		}catch(Exception exe) {
			exe.printStackTrace();
			if(conn != null) {
				conn.rollback();
				util.closeConnection(conn);
			}
		}
		return numberOfaffectedRows;
	}
	
	public int createActor(ActorTO actor) throws Exception {
		Connection conn = util.getConnection();
		PreparedStatement pStat = conn.prepareStatement(createActorQuery);
		pStat.setString(1, actor.getFirstName());
		pStat.setString(2, actor.getLastName());
		int numberOfRwosAffected = pStat.executeUpdate();
		util.closeConnection(conn);
		return numberOfRwosAffected;
	}
	
	public ArrayList<ActorTO> getActors() throws Exception {
		ArrayList<ActorTO> actors = new ArrayList<ActorTO>();
		Connection conn = util.getConnection();
		Statement stat = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
		ResultSet rs = stat.executeQuery(getAllActorsQuery);
		if(rs != null) {
			ActorTO actor = null;
			while(rs.next()) {
				actor = new ActorTO();
				int rowId = rs.getRow();
				if(rowId == 5) {
				//	rs.updateString("first_name", "QUBA");
				//	rs.updateRow();
					rs.refreshRow();
				}
				actor.setActorId(rs.getInt("actor_id"));
				actor.setFirstName(rs.getString("first_name"));
				actor.setLastName(rs.getString("last_name"));
				actor.setLastUpdate(rs.getTimestamp("last_update"));
				actors.add(actor);
				
				System.out.println("Row ID :: " + rowId + actor);
			}
		}
		util.closeConnection(conn);
		return actors;
	}
	
	
	public ActorTO getActor(int actorId) throws Exception {
		ActorTO actor = null;
		Connection conn = util.getConnection();
		PreparedStatement pStat = conn.prepareStatement(getActorforActorID);
		pStat.setInt(1, actorId);
		ResultSet rs = pStat.executeQuery();
		if(rs != null) {
			while(rs.next()) {
				actor = new ActorTO();
				actor.setActorId(rs.getInt("actor_id"));
				actor.setFirstName(rs.getString("first_name"));
				actor.setLastName(rs.getString("last_name"));
				actor.setLastUpdate(rs.getTimestamp("last_update"));
			}
		}
		util.closeConnection(conn);
		return actor;
	}
	
	
	
	
	
	public int updateActor(ActorTO actor) throws Exception {
		Connection conn = util.getConnection();
		PreparedStatement pStat = conn.prepareStatement(updateActorQuery);
		pStat.setString(1, actor.getFirstName());
		pStat.setString(2, actor.getLastName());
		pStat.setInt(3, actor.getActorId());
		int numberOfRwosAffected = pStat.executeUpdate();
		util.closeConnection(conn);
		return numberOfRwosAffected;
	}
	
	
	public int deleteActor(int actorId) throws Exception {
		Connection conn = util.getConnection();
		PreparedStatement pStat = conn.prepareStatement(deleteActorQuery);
		pStat.setInt(1, actorId);
		int numberOfRwosAffected = pStat.executeUpdate();
		util.closeConnection(conn);
		return numberOfRwosAffected;
	}
	
	public static void main(String[] args) throws Exception {
		ActorDAO dao = new ActorDAO();
		// dao.getActors();
		//ActorTO actor = dao.getActor(200);
		//System.out.println(actor.toString());
		/*
		 * ActorTO actor = new ActorTO(); actor.setFirstName("RAM");
		 * actor.setLastName("Raghuvanshi"); int insertSuccess = dao.createActor(actor);
		 * if (insertSuccess == 1) { System.out.println("Actor Inserted"); }
		 */
		
		ActorTO one = new ActorTO();
		one.setFirstName("Daniel");
		one.setLastName("D'selva");
		
		ActorTO two = new ActorTO();
		two.setFirstName("Yohani");
		two.setLastName("D'selva");
		
		ArrayList<ActorTO> actors = new ArrayList<ActorTO>();
		actors.add(one);
		actors.add(two);
		
		int rows = dao.createActors(actors);
		System.out.println("Rows Inserted :: " + rows);
	}
	

}
