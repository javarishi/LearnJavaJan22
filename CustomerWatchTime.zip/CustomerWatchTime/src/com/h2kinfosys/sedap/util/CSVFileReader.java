package com.h2kinfosys.sedap.util;

import java.util.List;

import com.h2kinfosys.sedap.dto.CustomerTO;

public class CSVFileReader {
	
	public List<CustomerTO> readCSVFile(String path) {
		
		List<CustomerTO> customerList = null;
		
		return customerList;
	}

}
