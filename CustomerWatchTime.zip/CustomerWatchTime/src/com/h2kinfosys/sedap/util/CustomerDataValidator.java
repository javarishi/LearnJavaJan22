package com.h2kinfosys.sedap.util;

import java.util.List;

import com.h2kinfosys.sedap.dto.CustomerTO;

public class CustomerDataValidator {
	
	public List<CustomerTO> validateCustomers(List<CustomerTO> customers){
		
		String errorMessage = validateCustomerID(customers.get(0).getCustomerId());
		
		return null;
	}
	
	public String validateCustomerID(String customerId) {
		return null;
	}

}
