package com.h2kinfosys.sedap.service;

public class SedapTrigger {

	public static void main(String[] args) {
		// TODO 1. Read File - provided in args[0]
		// TODO 2. Validator
		// TODO 3. Separation of Errors - send to ActiveMQ 
		// TODO 4. Batch Insert to DB 
		// TODO 5. Send an Email 

	}

}
